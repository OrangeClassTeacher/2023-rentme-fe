export const NotFoundPage = () => {
    return (
      <div>
        <h1>Not found</h1>
        <p>Looks like this page does not exist</p>
      </div>
    );
  };
