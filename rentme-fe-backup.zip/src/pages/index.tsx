import { Inter } from "next/font/google";
import NewsImageSection from "../components/Home/NewsImagesSection"
const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  return (
    <div>
      {/* <NewsImageSection/> */}
    </div>
  );
}
