import react from "react";


export const SearchBox = () =>{
  return(
    <></>
  )
}
